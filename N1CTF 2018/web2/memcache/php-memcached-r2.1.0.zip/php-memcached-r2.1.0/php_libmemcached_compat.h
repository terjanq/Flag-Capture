#ifndef PHP_LIBMEMCACHED_COMPAT
#define PHP_LIBMEMCACHED_COMPAT

/* this is the version(s) we support */
#include <libmemcached-1.0/memcached.h>

#endif
